x = 10
print(type(x))

x = "Manuel"
print(type(x))

x = 3.14
print(type(x))
