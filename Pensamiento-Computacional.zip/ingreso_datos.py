# print("Ingrese un valor")
# valor = input()

print(numero)
print(type(numero))

numero = float(input("Ingrese un numero: "))
otro_numero = float(input("Ingrese otro numero: "))
# Si no especificamos en los input el tipo de dato que se va a aceptar, el valor que ingresamos se va a tratar como un string

suma = numero + otro_numero
print(suma)
